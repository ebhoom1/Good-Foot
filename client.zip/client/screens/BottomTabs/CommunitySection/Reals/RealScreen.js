// RealScreen.js
import React from 'react';
import { View, Text } from 'react-native';

const RealScreen = () => {
    return (
        <View>
            <Text>Real Screen</Text>
        </View>
    );
};

export default RealScreen;
